package zzp.tools.apksigner;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class T {
	public static void main(String[] args) throws IOException,
			InterruptedException {
		Process p = Runtime.getRuntime().exec("cmd /C java");
		InputStream in = p.getErrorStream();
		if (in != null) {
			System.out.println(">>>>>>>>>error");
			print(in);
		}
		in = p.getInputStream();
		if (in != null) {
			System.out.println(">>>>>>>>>input");
			print(in);
		}
		p.destroy();
		p.waitFor();
	}

	public static void print(InputStream in) throws IOException {
		if (in != null) {
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					in, "GBK"));
			String line = null;
			while ((line = reader.readLine()) != null) {
				System.out.println(line);
			}
		}
	}
}