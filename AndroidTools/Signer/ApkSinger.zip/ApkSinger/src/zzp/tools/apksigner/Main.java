package zzp.tools.apksigner;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.WindowConstants;
import javax.swing.filechooser.FileSystemView;

public class Main {
	private static final String CONFIG_FILE = ".zzp.tools.apksigner.config";

	public static void main(String[] args) {
		new Main().show();
	}

	private Process p;
	private Properties config = new Properties();
	private JFrame frame;
	private JFileChooser fileChooser;
	private JTextArea ta_console;
	private JTextField tf_unsignedapk;
	private JTextField tf_keystore;
	private JTextField tf_save;
	private JTextField tf_alias;
	private JTextField tf_storepass;
	private JTextField tf_keyepass;
	private JButton bt_sign;

	private Main() {
		loadConfig();
		frame = new JFrame("APKǩ������");
		frame.setSize(750, 750);
		Dimension frameSize = frame.getSize();
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		frame.setLocation(
				(int) (screenSize.getWidth() - frameSize.getWidth()) / 2,
				(int) (screenSize.getHeight() - frameSize.getHeight()) / 2);
		frame.setResizable(false);
		// frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
		frame.setLayout(new FlowLayout(FlowLayout.LEFT));
		frame.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				if (p != null) {
					int result = JOptionPane.showConfirmDialog(frame,
							"����ǩ���У��Ƿ���ֹ��", "ȷ���˳�", JOptionPane.YES_NO_OPTION,
							JOptionPane.QUESTION_MESSAGE);
					if (result == JOptionPane.YES_OPTION) {
						try {
							p.getInputStream().close();
							p.getErrorStream().close();
							p.destroy();
						} catch (IOException e1) {
							e1.printStackTrace();
						}
						p = null;
						exit();
					}
				} else {
					exit();
				}
			}
		});

		fileChooser = new JFileChooser();
		fileChooser.setCurrentDirectory(FileSystemView.getFileSystemView()
				.getHomeDirectory());
		fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);

		// δǩ���ļ�ѡ��
		tf_unsignedapk = new JTextField();
		Dimension size = tf_unsignedapk.getPreferredSize();
		size.width = 600;
		tf_unsignedapk.setPreferredSize(size);
		JButton bt_chooseapk = new JButton("ѡ��apk");
		size = bt_chooseapk.getSize();
		size.width = 100;
		bt_chooseapk.setSize(size);
		JPanel pannel = new JPanel();
		pannel.add(tf_unsignedapk);
		pannel.add(bt_chooseapk);
		frame.add(pannel);

		// ֤��ѡ��
		tf_keystore = new JTextField();
		size = tf_keystore.getPreferredSize();
		size.width = 600;
		tf_keystore.setPreferredSize(size);
		JButton bt_keystore = new JButton("ѡ��֤���");
		size = bt_keystore.getPreferredSize();
		size.width = 100;
		bt_keystore.setPreferredSize(size);
		pannel = new JPanel();
		pannel.add(tf_keystore);
		pannel.add(bt_keystore);
		frame.add(pannel);
		tf_keystore.setText(config.getProperty("keystore"));

		// ����λ��
		tf_save = new JTextField();
		size = tf_save.getPreferredSize();
		size.width = 600;
		tf_save.setPreferredSize(size);
		JButton bt_save = new JButton("����λ��");
		size = bt_save.getPreferredSize();
		size.width = 100;
		bt_save.setPreferredSize(size);
		pannel = new JPanel();
		pannel.add(tf_save);
		pannel.add(bt_save);
		frame.add(pannel);

		// ֤�����Ϣ����
		// GridBagLayout gridbadlayout = new GridBagLayout();
		// gridbadlayout.columnWidths = new int[] { 100, 500 };
		// pannel = new JPanel();
		// pannel.setLayout(gridbadlayout);
		// frame.add(pannel);

		JLabel label_alias = new JLabel("֤�����");
		setWidth(label_alias, 100);
		tf_alias = new JTextField();
		size = tf_alias.getPreferredSize();
		size.width = 500;
		tf_alias.setPreferredSize(size);
		pannel = new JPanel();
		pannel.add(label_alias);
		pannel.add(tf_alias);
		frame.add(pannel);
		tf_alias.setText(config.getProperty("alias"));

		JLabel label_storepass = new JLabel("֤�������");
		setWidth(label_storepass, 100);
		tf_storepass = new JTextField();
		size = tf_storepass.getPreferredSize();
		size.width = 500;
		tf_storepass.setPreferredSize(size);
		pannel = new JPanel();
		pannel.add(label_storepass);
		pannel.add(tf_storepass);
		frame.add(pannel);
		tf_storepass.setText(config.getProperty("storepass"));

		JLabel label_keypass = new JLabel("֤������");
		setWidth(label_keypass, 100);
		tf_keyepass = new JTextField();
		size = tf_keyepass.getPreferredSize();
		size.width = 500;
		tf_keyepass.setPreferredSize(size);
		pannel = new JPanel();
		pannel.add(label_keypass);
		pannel.add(tf_keyepass);
		frame.add(pannel);
		tf_keyepass.setText(config.getProperty("keypass"));

		// ȷ��
		bt_sign = new JButton("ȷ��");
		size = bt_sign.getPreferredSize();
		size.width = 600;
		bt_sign.setPreferredSize(size);
		frame.add(bt_sign);

		ta_console = new JTextArea();
		ta_console.setAutoscrolls(true);
		ta_console.setEditable(false);
		// ta_console.setEnabled(false);
		ta_console.setBackground(Color.GRAY);
		ta_console.setForeground(Color.WHITE);
		JScrollPane scroll = new JScrollPane(ta_console);
		scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		setWidth(scroll, 730);
		setHeight(scroll, 430);
		frame.add(scroll);

		// ѡ��apk
		bt_chooseapk.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String unsigneddir = config.getProperty("unsigned_dir");
				fileChooser.setCurrentDirectory(new File(unsigneddir));
				int result = fileChooser.showOpenDialog(frame);
				if (result == JFileChooser.APPROVE_OPTION) {
					File file = fileChooser.getSelectedFile();
					if (file != null) {
						tf_unsignedapk.setText(file.getAbsolutePath());
					}
				}
			}
		});

		// ѡ��֤���
		bt_keystore.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				fileChooser.setCurrentDirectory(FileSystemView
						.getFileSystemView().getHomeDirectory());
				int result = fileChooser.showOpenDialog(frame);
				if (result == JFileChooser.APPROVE_OPTION) {
					File file = fileChooser.getSelectedFile();
					if (file != null) {
						tf_keystore.setText(file.getAbsolutePath());
					}
				}
			}
		});

		// ����λ��
		bt_save.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int result = fileChooser.showSaveDialog(frame);
				if (result == JFileChooser.APPROVE_OPTION) {
					File file = fileChooser.getSelectedFile();
					if (file != null) {
						if (file.exists()) {
							int rtn = JOptionPane.showOptionDialog(frame,
									"�ļ��Ѵ��ڣ��Ƿ񸲸ǣ�", "��ʾ",
									JOptionPane.OK_CANCEL_OPTION,
									JOptionPane.QUESTION_MESSAGE, null,
									new String[] { "����", "ȡ��" }, "ȡ��");
							if (rtn == JOptionPane.OK_OPTION) {
								tf_save.setText(file.getAbsolutePath());
							}
						} else {
							tf_save.setText(file.getAbsolutePath());
						}
					}
				}
			}
		});

		// ���ǩ����ť
		bt_sign.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (checkUnsignedApk(tf_unsignedapk.getText())) {
					startSign(tf_unsignedapk.getText(), tf_keystore.getText(),
							tf_save.getText(), tf_storepass.getText(),
							tf_alias.getText(), tf_keyepass.getText());
				}
			}
		});
	}

	private void startSign(final String apkFile, final String keyfile,
			final String savedfile, final String storepass, final String alias,
			final String keypass) {
		frame.setEnabled(false);
		new Thread() {
			@Override
			public void run() {
				doSign(apkFile, keyfile, savedfile, storepass, alias, keypass);
			};
		}.start();
	}

	private void doSign(String apkFile, String keyfile, String savedfile,
			String storepass, String alias, String keypass) {
		System.out.println("��ʼǩ��");
		System.out.println(apkFile);
		System.out.println(keyfile);
		System.out.println(savedfile);
		System.out.println(storepass);
		System.out.println(alias);
		System.out.println(keypass);
		try {
			// jarsigner -verbose -keystore key.keystore -signedjar signed.apk
			// -digestalg SHA1 -sigalg MD5withRSA uucun.apk boyaafitloadland
			StringBuilder sb = new StringBuilder();
			sb.append("cmd /C jarsigner -verbose -keystore ");
			sb.append("\"").append(keyfile).append("\"");
			sb.append(" -signedjar ");
			sb.append("\"").append(savedfile).append("\" ");
			sb.append("-digestalg SHA1 -sigalg MD5withRSA");
			sb.append(" -storepass ");
			sb.append(storepass);
			sb.append(" -keypass ");
			sb.append(keypass).append(" ");
			sb.append("\"").append(apkFile).append("\" ");
			sb.append(alias);
			String cmd = sb.toString();
			System.out.println(cmd);
			p = Runtime.getRuntime().exec(cmd);
			InputStream in = p.getInputStream();
			InputStream error = p.getInputStream();
			BufferedReader reader = new BufferedReader(
					new InputStreamReader(in));
			String line = null;
			while ((line = reader.readLine()) != null) {
				writeToTextArea(line);
			}

			reader = new BufferedReader(new InputStreamReader(error));
			line = null;
			while ((line = reader.readLine()) != null) {
				writeToTextArea(line);
			}
			p.waitFor();
			in.close();
			error.close();
			p.destroy();
			p = null;
			writeToTextArea("---------------\nǩ�����");
		} catch (Throwable e) {
			e.printStackTrace();
		} finally {
			frame.setEnabled(true);
		}
	}

	private final Object lock = new Object();

	private void writeToTextArea(String line) {
		synchronized (lock) {
			ta_console.append(line);
			ta_console.append("\n");
			ta_console.setCaretPosition(ta_console.getText().length());
		}
	}

	private boolean checkUnsignedApk(String apkFile) {
		File file = new File(apkFile);
		if (!file.exists()) {
			JOptionPane.showMessageDialog(frame, "apk�ļ������� ");
			return false;
		}
		ZipFile zip = null;
		try {
			zip = new ZipFile(file);
			ZipEntry manifest = zip.getEntry("META-INF/MANIFEST.MF");
			if (manifest != null) {
				JOptionPane.showMessageDialog(frame,
						"���ֶ�ɾ����ǩ��apk�ļ��ڵ�META-INF�ļ��С�");
				zip.close();
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(frame, "apk�ļ�������");
			return false;
		} finally {
			try {
				zip.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return true;
	}

	private void loadConfig() {
		try {
			File file = new File(FileSystemView.getFileSystemView()
					.getDefaultDirectory(), CONFIG_FILE);
			if (file.exists()) {
				FileInputStream in = new FileInputStream(file);
				config.clear();
				config.load(in);
				in.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void saveConfig() {
		try {
			File file = new File(FileSystemView.getFileSystemView()
					.getDefaultDirectory(), CONFIG_FILE);
			Properties props = new Properties();
			props.put("unsigned_dir", tf_unsignedapk.getText());
			props.put("keystore", tf_keystore.getText());
			props.put("save_dir", tf_save.getText());
			props.put("alias", tf_alias.getText());
			props.put("storepass", tf_storepass.getText());
			props.put("keypass", tf_keyepass.getText());
			FileOutputStream out = new FileOutputStream(file);
			props.store(out, null);
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void setWidth(Component component, int width) {
		Dimension size = component.getPreferredSize();
		size.width = width;
		component.setPreferredSize(size);
	}

	private void setHeight(Component component, int height) {
		Dimension size = component.getPreferredSize();
		size.height = height;
		component.setPreferredSize(size);
	}

	private void show() {
		frame.setVisible(true);
	}

	private void exit() {
		frame.dispose();
		System.exit(0);
	}
}